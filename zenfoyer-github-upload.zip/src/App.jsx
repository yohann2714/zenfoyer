import React from 'react';

function App() {
  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold text-center text-indigo-600">Bienvenue sur ZenFoyer</h1>
      <p className="text-center mt-4">Tout fonctionne ! Cette version est prête pour Vercel.</p>
    </div>
  );
}

export default App;
